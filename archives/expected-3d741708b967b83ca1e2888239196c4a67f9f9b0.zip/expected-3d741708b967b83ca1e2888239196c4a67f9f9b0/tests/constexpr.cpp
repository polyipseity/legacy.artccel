#include "catch.hpp"
#include <tl/expected.hpp>

TEST_CASE("Constexpr", "[constexpr]") {
    //TODO
}
